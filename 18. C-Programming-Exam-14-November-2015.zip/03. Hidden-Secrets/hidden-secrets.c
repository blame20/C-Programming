#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define BUFFER_SIZE 64
#define FILE_NAME_SIZE 64

void create_file_name(char buffer[], size_t maxSize, const char *fileName, const char *srcFileName);

void kill(const char *msg);

void file_kill(const char *msg, FILE *stream, const char *fileName);

int main(int argc, char **argv) 
{
    if (argc < 2)
        kill("Usage: ./prog [<file-1> <file-2> ...]\n");
    size_t fileCount = argc - 1;
    char **files = argv + 1;
    
    char resultFileName[FILE_NAME_SIZE];
    create_file_name(resultFileName, FILE_NAME_SIZE, "merged", files[0]);
    
    FILE *resultFile = fopen(resultFileName, "wb");
    if (!resultFile)
        kill(NULL);
    
    char buffer[BUFFER_SIZE];
    
    char appleCipher[4] = { 0x33, 0x34, 0x35, 0x36 };
    char leafCipher[4] = { 0x21, 0x22, 0x23, 0x24 };
//    char crossCipher[4] = { 0x2B, 0x2C, 0x2D, 0x2E };
    
    size_t i;
    for (i = 0; i < fileCount; i++)
    {
        FILE *currentPart = fopen(files[i], "rb");
        if (!currentPart)
            file_kill(files[i], resultFile, resultFileName);
        
        while (1)
        {
            size_t readBytes = fread(buffer, 1, BUFFER_SIZE, currentPart);
            if (readBytes == 0)
                break;
            
            char *currentSign = buffer + readBytes - 4;
            size_t writtenBytes;
            if (memcmp(currentSign, appleCipher, 4) == 0)
            {
                writtenBytes = fwrite(buffer, 1, readBytes - 4, resultFile);
            }
            else if (memcmp(currentSign, leafCipher, 4) == 0)
            {
                size_t firstHalf = (readBytes - 4) / 2;
                writtenBytes = fwrite(buffer, 1, firstHalf, resultFile);
            }
            else 
            {
                continue;
            }
            
            if (writtenBytes == 0)
                break;
        }
        
        if (ferror(currentPart))
        {
            fclose(currentPart);
            file_kill("Error reading from part\n", resultFile, resultFileName);
        }
        
        if (ferror(resultFile))
        {
            fclose(currentPart);
            file_kill("Error writing to result\n", resultFile, resultFileName);
        }
        
        fclose(currentPart);
    }
    
    fclose(resultFile);
    
    printf("Done!\n");
    
    return (EXIT_SUCCESS);
}

void create_file_name(char buffer[], size_t maxSize, const char *fileName, const char *srcFileName)
{
    char *extension = strrchr(srcFileName, '.');
    snprintf(buffer, maxSize, "%s%s", fileName, extension);
}

void kill(const char *msg)
{
    if (errno)
        perror(msg);
    else 
        fprintf(stderr, "%s\n", msg);
    
    exit(1);
}

void file_kill(const char *msg, FILE *stream, const char *fileName)
{
    fclose(stream);
    remove(fileName);
    kill(msg);
}