#include <stdio.h>
#include <stdlib.h>

int main() 
{
    float boardX, boardY, boardRadius;
    float headX, headY, headRadius;
    float armTopX, armTopY, armBotX, armBotY;
    scanf("%f %f %f", &boardX, &boardY, &boardRadius);
    scanf("%f %f %f", &headX, &headY, &headRadius);
    scanf("%f %f %f %f", &armTopX, &armTopY, &armBotX, &armBotY);
    
    int shotsCount, i;
    int successfulShots = 0;
    int points = 0;
    int bayMileHealth = 100;
    int shotsFired = 0;
    
    float dartX, dartY;
    scanf("%d", &shotsCount);
    
    for (i = 0; i < shotsCount; i++)
    {
        scanf("%f %f", &dartX, &dartY);
        float distanceFromBoardX = (boardX - dartX);
        float distanceFromBoardY = (boardY - dartY);
        float distanceFromBoardCenter = distanceFromBoardX * distanceFromBoardX + 
                                         distanceFromBoardY * distanceFromBoardY;
        int isInsideBoard = distanceFromBoardCenter <= boardRadius * boardRadius;
        
        float distanceFromHeadX = (headX - dartX);
        float distanceFromHeadY = (headY - dartY);
        float distanceFromHeadCenter = distanceFromHeadX * distanceFromHeadX +
                                        distanceFromHeadY * distanceFromHeadY;
        int isInsideHead = distanceFromHeadCenter <= headRadius * headRadius;
        
        int isInsideArm = (dartX >= armTopX && dartX <= armBotX) &&
                          (dartY <= armTopY && dartY >= armBotY);
        
        if (isInsideBoard)
        {
            if (isInsideHead || isInsideArm)
            {
                points += 25;
            }
            else
            {
                points += 50;
            }
            
            successfulShots++;
        }
        
        if (isInsideHead)
        {
            bayMileHealth -= 25;
        }

        if (isInsideArm)
        {
            bayMileHealth -= 30;
        }
        
        shotsFired++;
        
        if (bayMileHealth <= 0)
        {
            bayMileHealth = 0;
            break;
        }
    }   
    
    int hitRatio = (successfulShots / (float)(shotsFired)) * 100;
    printf("Points: %d\nHit ratio: %d%%\nBay Mile: %d", 
            points, hitRatio, bayMileHealth);
    
    return (EXIT_SUCCESS);
}
