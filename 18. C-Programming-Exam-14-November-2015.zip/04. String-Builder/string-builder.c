#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_BUFFER_SIZE 64
#define COMMAND_SIZE 65
#define COMMAND_DELIMITER "-"

typedef struct StringBuilder {
    char *buffer;
    size_t length;
    size_t size;
} StringBuilder;

void concat(StringBuilder *sb, const char *src);

void insert(StringBuilder *sb, const char *src, size_t index);

void replace(StringBuilder *sb, const char *oldValue, const char *newValue);

void resize(StringBuilder *sb, size_t size);

void kill();

int main() 
{
    StringBuilder sb;
    sb.buffer = (char*) calloc(INITIAL_BUFFER_SIZE, sizeof(char));
    sb.length = 0;
    sb.size = INITIAL_BUFFER_SIZE;
	
    char command[COMMAND_SIZE] = {0};

    while (1) 
    {
        fgets(command, COMMAND_SIZE, stdin);
        size_t length = strlen(command);
        if (command[length - 1] == '\n')
            command[length - 1] = '\0';

        if (strcmp(command, "over") == 0)
            break;

        char *action = strtok(command, COMMAND_DELIMITER);
        char *str = strtok(NULL, COMMAND_DELIMITER);
        if (strcmp(action, "concat") == 0) 
        {
            concat(&sb, str);
        }
        else if (strcmp(action, "insert") == 0)
        {
            size_t position = atol(strtok(NULL, COMMAND_DELIMITER));
            insert(&sb, str, position);
        }
        else 
        {
            char *replacement = strtok(NULL, COMMAND_DELIMITER);
            replace(&sb, str, replacement);
        }
    } 
    
    printf("%s\n", sb.buffer);
    
    free(sb.buffer);
    
    return (EXIT_SUCCESS);
}

void concat(StringBuilder *sb, const char *src)
{
    size_t srcLength = strlen(src);
    size_t newLength = sb->length + srcLength;
    if (newLength >= sb->size - 1)
        resize(sb, sb->size * 2);
    
    strcat(sb->buffer, src);
    sb->length += srcLength;
    sb->buffer[sb->length] = '\0';
}

void insert(StringBuilder *sb, const char *src, size_t position)
{
    size_t srcLength = strlen(src);
    size_t newLength = sb->length + srcLength;
    if (newLength >= sb->size - 1)
        resize(sb, sb->size * 2);
    
    char *insertPtr = sb->buffer + position; 
    char *movePtr = sb->buffer + position + srcLength;
    
    memmove(movePtr, insertPtr, sb->length - position);
    memcpy(insertPtr, src, srcLength);
    
    sb->length += srcLength;
    sb->buffer[sb->length] = '\0';
}

void replace(StringBuilder *sb, const char *oldValue, const char *newValue)
{
    size_t oldLength = strlen(oldValue);
    size_t newLength = strlen(newValue);
    
    char *match, 
         *startPtr = sb->buffer;
    while (match = strstr(startPtr, oldValue))
    {
        if (newLength - oldLength + sb->length >= sb->size - 1)
            resize(sb, sb->size * 2);
        
        // Calculate characters count after match
        size_t charactersToMove = sb->length - (match - sb->buffer) - oldLength;
            
        char *destMovePtr = match + newLength;
        char *srcMovePtr = match + oldLength;
        memmove(destMovePtr, srcMovePtr, charactersToMove);
        memcpy(match, newValue, newLength);
        
        sb->length += newLength - oldLength;
        startPtr = destMovePtr;
        sb->buffer[sb->length] = '\0';
    }
}

void resize(StringBuilder *sb, size_t size)
{
    char *resized = (char*) realloc(sb->buffer, size);
    if (!resized) 
        kill();
    
    sb->buffer = resized;
    sb->size = size;
}

void kill()
{
    perror(NULL);
    exit(1);
}