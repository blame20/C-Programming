#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define COMMAND_SIZE 10

int get_bit(unsigned int num, int position);

void set_bit(unsigned int *num, int position, int bit);

int main()
{
    int n;
    scanf("%d", &n);
    
    unsigned int numbers[n];
    int i;
    for (i = 0; i < n; i++)
    {
        scanf("%u", &numbers[i]);
    }
    
    getchar();
    
    char command[COMMAND_SIZE];
    fgets(command, COMMAND_SIZE, stdin);
    int pos = 0, row = 0;
    while (strcmp(command, "end\n") != 0)
    {
        size_t len = strlen(command);
        if (command[len - 1] == '\n')
            command[len - 1] = '\0';
        
        int newPos = pos, newRow = row;
        if (strcmp(command, "right") == 0)
        {
            newPos = pos - 1;
            if (newPos < 0)
            {
                newPos = 31;
            }
        }
        else if (strcmp(command, "left") == 0)
        {
            newPos = pos + 1;
            if (newPos >= 32)
            {
                newPos = 0;
            }
        }
        else if (strcmp(command, "up") == 0)
        {
            newRow = row - 1;
            if (newRow < 0)
            {
                newRow = n - 1;
            }
        }
        else 
        {
            newRow = row + 1;
            if (newRow >= n)
            {
                newRow = 0;
            }
        }
        
        int bit = get_bit(numbers[newRow], newPos);
        if (bit == 1)
        {
            printf("GAME OVER. Stepped a mine at %d %d\n", newRow, newPos);
            break;
        }
        
        set_bit(&numbers[row], pos, 0);
        set_bit(&numbers[newRow], newPos, 1);
        row = newRow;
        pos = newPos;
        
        fgets(command, COMMAND_SIZE, stdin);
    }
    
    for (i = 0; i < n; i++)
    {
        printf("%u\n", numbers[i]);
    }
    
    return (EXIT_SUCCESS);
}

int get_bit(unsigned int num, int position)
{
    return (num >> position) & 1;
}

void set_bit(unsigned int *num, int position, int bit)
{
    if (bit == 1)
        *num |= 1U << position;
    else 
        *num &= ~(1U << position);
}