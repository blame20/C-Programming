#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

typedef int BOOL;

/* CONSTANTS AND MACROS */
#define TRUE 1
#define FALSE 0

#define MAX_DATA 50
#define BIT_COUNT 32
#define INITIAL_ROW 0
#define INITIAL_COL 0

#define LEFT 0, 1
#define RIGHT 0, -1
#define UP -1, 0
#define DOWN 1, 0


/* FUNCTION PROTOTYPES */

void ProcessGame();
BOOL ProcessCommand(char * command);
BOOL ProcessMove(int velRow, int velCol);
int GetBitAtPosition(int number, int position);
void SetBitAtPosition(int * number, int position, int bit);
void PrintBinary(int number);
void PrintGameOver();
void PrintNumbersInBinary();
void ProcessInput();
void PrintNumbers();
void InitializeData();
void DisposeData();

/* LOCAL DATA */
static int * numbers;

static int numbersCount;
static int playerRow;
static int playerCol;

int main()
{
    ProcessInput();
    ProcessGame();
    PrintNumbers();
    DisposeData();

    return 0;
}

void ProcessGame()
{
    char input[MAX_DATA];

    // PrintNumbersInBinary();
    scanf("%s", input);

    while (strcmp(input, "end") != 0)
    {
        BOOL isDead = ProcessCommand(input);
        // PrintNumbersInBinary();

        if (isDead)
        {
            PrintGameOver();
            return;
        }

        scanf("%s", input);
    }
}

BOOL ProcessCommand(char * command)
{
    BOOL result = FALSE;

    if (strcmp(command, "left") == 0)
    {
        result = ProcessMove(LEFT);
    }
    else if (strcmp(command, "right") == 0)
    {
        result = ProcessMove(RIGHT);
    }
    else if (strcmp(command, "up") == 0)
    {
        result = ProcessMove(UP);
    }
    else if (strcmp(command, "down") == 0)
    {
        result = ProcessMove(DOWN);
    }
    else
    {
        assert(0);
    }

    return result;
}

BOOL ProcessMove(int velRow, int velCol)
{
    BOOL isDead = FALSE;
    int newRow = playerRow + velRow;
    int newCol = playerCol + velCol;

    if (newRow < 0)
    {
        newRow = numbersCount - 1;
    }
    else if (newRow >= numbersCount)
    {
        newRow = 0;
    }

    if (newCol < 0)
    {
        newCol = BIT_COUNT - 1;
    }
    else if (newCol >= BIT_COUNT)
    {
        newCol = 0;
    }

    int bit = GetBitAtPosition(numbers[newRow], newCol);

    if (bit == 0)
    {
        SetBitAtPosition(&numbers[playerRow], playerCol, 0);
        SetBitAtPosition(&numbers[newRow], newCol, 1);
    }
    else
    {
        isDead = TRUE;
    }

    playerRow = newRow;
    playerCol = newCol;

    return isDead;
}

void ProcessInput()
{
    scanf("%d", &numbersCount);

    InitializeData();

    for (int cnt = 0; cnt < numbersCount; ++cnt)
    {
        scanf("%d", &numbers[cnt]);
    }
}

void InitializeData()
{
    numbers = (int*)malloc(sizeof(int) * numbersCount);
}

void DisposeData()
{
    free(numbers);
}

int GetBitAtPosition(int number, int position)
{
    return (number >> position) & 1;
}

void SetBitAtPosition(int * number, int position, int bit)
{
    if (bit == 0)
    {
        (*number) &= ( ~(1 << position));
    }
    else
    {
        (*number) |= 1 << position;
    }
}

void PrintNumbersInBinary()
{
    for (int index = 0; index < numbersCount; ++index)
    {
        PrintBinary(numbers[index]);
    }
}

void PrintBinary(int number)
{
    int bit;

    // Pad with zeroes
    for (bit = BIT_COUNT - 1; bit >= 0; --bit)
    {
        if ((number >> bit) & 1)
        {
            break;
        }

        printf("0");
    }

    while (bit >= 0)
    {
        printf("%d", ( (number >> bit) & 1));
        --bit;
    }

    printf("\n");
}

void PrintGameOver()
{
    printf("GAME OVER. Stepped a mine at %d %d\n", playerRow, playerCol);
}

void PrintNumbers()
{
    for (int cnt = 0; cnt < numbersCount; ++cnt)
    {
        printf("%lu\n", numbers[cnt]);
    }
}
